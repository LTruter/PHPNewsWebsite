/*
Filename: db_users.sql
Author: Lario Truter
Created: ‎29 ‎November ‎2023
Description: Creates database "users" if it does not exist.
*/

CREATE DATABASE IF NOT EXISTS users;