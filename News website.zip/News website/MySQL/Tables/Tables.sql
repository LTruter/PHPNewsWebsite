/*
Filename: Tables.sql
Author: Lario Truter
Created: ‎29 ‎November ‎2023
Description: Uses the database "users" and creates the specified tables if they do not exist.
*/

USE users;

/* Registration information */
CREATE TABLE IF NOT EXISTS user_regist(
	first_name VARCHAR(30) NOT NULL, 
	last_name VARCHAR(30) NOT NULL, 
	gender ENUM('Male', 'Female', 'Other') NOT NULL, 
	date_of_birth DATE NOT NULL, 
	email VARCHAR(100) NOT NULL, 
	contact_number VARCHAR(10) NOT NULL, 
	email_newsletter BOOLEAN,
	username VARCHAR(30) NOT NULL,
	password VARCHAR(50) NOT NULL,
	PRIMARY	KEY(username)
);

/* User uploaded news articles */
CREATE TABLE IF NOT EXISTS news_articles(
	article_id INT NOT NULL AUTO_INCREMENT,
	article_heading VARCHAR(255) NOT NULL,
	article TEXT NOT NULL,
	article_type ENUM('Sport', 'Business', 'Entertainment') NOT NULL,
	article_date DATE NOT NULL,
	image_path VARCHAR(255) NOT NULL,
	article_url	VARCHAR(255) NOT NULL,
	username VARCHAR(30) NOT NULL,
	PRIMARY KEY(article_id),
	FOREIGN KEY(username) REFERENCES user_regist(username)
);

/* Comments the user leaves on news article posts */
CREATE TABLE IF NOT EXISTS user_comments(
	comment_id INT NOT NULL AUTO_INCREMENT,
	article_id INT NOT NULL,
	username VARCHAR(30) NOT NULL,
	comment_text TEXT NOT NULL,
	date_posted TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(comment_id),
	FOREIGN KEY(article_id) REFERENCES news_articles(article_id),
	FOREIGN KEY(username) REFERENCES user_regist(username)
);

/* Galleries the users create */
CREATE TABLE IF NOT EXISTS created_galleries(
	gallery_id INT NOT NULL AUTO_INCREMENT,
	gallery_name VARCHAR(255) NOT NULL,
	date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	username VARCHAR(30) NOT NULL,
	PRIMARY KEY(gallery_id),
	FOREIGN KEY(username) REFERENCES user_regist(username)
);

/* Images stored to the galleries */
CREATE TABLE IF NOT EXISTS gallery_images(
	image_id INT NOT NULL AUTO_INCREMENT,
	gallery_img_path VARCHAR(255) NOT NULL,
	date_uploaded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	gallery_id INT NOT NULL,
	PRIMARY KEY(image_id),
	FOREIGN KEY(gallery_id) REFERENCES created_galleries(gallery_id)
);
