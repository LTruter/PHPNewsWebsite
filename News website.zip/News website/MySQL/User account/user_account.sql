/*
Filename: user_account.sql
Author: Lario Truter
Created: ‎‎29 ‎November ‎2023
Description: Creates user 'ODBC' if the user does not exist and grants the user all privileges
*/

CREATE USER IF NOT EXISTS 'ODBC'@'localhost' IDENTIFIED BY '';

GRANT ALL PRIVILEGES ON *.* TO 'ODBC'@'localhost' IDENTIFIED BY '' WITH GRANT OPTION;