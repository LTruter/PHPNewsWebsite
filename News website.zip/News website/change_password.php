<!DOCTYPE html>
<!--
Filename: change_password.php
Author: Lario Truter
Created: 29 November 2023
Description: The user can change their password using the form.
-->
<?php
	session_start();
?>
<html>
	<head>		
		<title> Change Password </title>
		
		<link rel="stylesheet" href="CSS/stylesheet.css">
	</head>
	
	<body>
		<?php
			// Include the header
			include_once "header.php";

			// require_once is used to make sure that if the specific file cannot be included, then it will cause a fatal error
			// require_once is used because I'm not going to include it again
			require_once "user_exists.php";
			require_once "db_connection.php";
			require_once "logout.php";
			
			// Defining the variable that will prevent the form from being submitted
			$incorrect_input = false;
			
			// Define error message variables
			$entered_username_err_msg = "";
			$current_password_err_msg = "";
			$new_password_err_msg = "";
			
			// Define the password successfully changed variable
			$password_success_msg = "";
			
			// Define the password failed to change variable
			$password_err_msg = "";
			
			// If statement checks the $_SERVER global variable to see if the request method used for the form is the POST method (The code inside can't run if this requirement is not met)
			if($_SERVER["REQUEST_METHOD"] == "POST"){
				
				// Store the input data to variables
				$entered_username = $_POST["log-username"];
				$current_password = $_POST["current-password"];
				$new_password = $_POST["new-password"];
				
				// Validation for username
				// Checks if the username input is empty
				if(empty($entered_username)) {
					
					$entered_username_err_msg = "Username is required";
					
					$incorrect_input = true;
					
				} 
					
				// Validation for current password	
				// Checks if the current password input is empty
				if(empty($current_password)) {
					
					$current_password_err_msg = "Current password is required";
					
					$incorrect_input = true;
				
				}
				
				// Validation for new password
				// Checks if the new password input is empty
				if(empty($new_password)) {
					
					$new_password_err_msg = "New password is required";
					
					$incorrect_input = true;
				
				} else {
					
					// Checks if the string length of the password is longer than 10 characters
					if(strlen($new_password) > 50) {
						
						$new_password_err_msg = "Password can not be longer than 50 characters";
						
						$incorrect_input = true;						
					
					}
				}
				
				
				// If any of the validations are failed $incorrect_input will evaluate to true and the if statement will only run if $incorrect_input is NOT true
				if(!$incorrect_input) {
					
					// Query the database to see if the username and password exist
					$sql = "SELECT * FROM user_regist WHERE username = '$entered_username' AND password = '$current_password'";
					
					// Query the query
					$result = $conn->query($sql);
					
						// If statement checks if the query was made without any errors
						if($result) {
							
							// If statement checks the $result variable to see if only 1 row matches the requirements
							if($result->num_rows == 1){
								
								// If statement to check that the $new_password does NOT equal the $current_password
								if($new_password != $current_password){
									
									// Sanitise the new password before it's stored to the database
									$new_password = mysqli_real_escape_string($conn, $_POST["new-password"]);
									
									// Query to update the password to the new password
									$sql = "UPDATE user_regist SET password = '$new_password' where username = '$entered_username'";
									
									// Query the query
									$update = $conn->query($sql);
									
										// If statement to check if the query was made without errors
										if($update){
											
											// The password success message
											$password_success_msg = "Password changed successfully <br>";
										
										} else {
											
											// echo "Query failed: " . $conn->error . "<br>"; 
											
										}
										
								} else {
									
									$password_err_msg = "New password can not be the same as the current password <br>";
									
								}
							
							} else {
								
								$password_err_msg = "Username or password is incorrect <br>";
								
							}
						
						} else {
							
							// echo "Query failed: " . $conn->error . "<br>";
						
						}
					
					// Close the database connection
					$conn->close();
					
				}
			}
		?>
		
		
		<main class="page-height">
			<div class="grid-container">
				<div class="form-outline">
					<h2> Change Password </h2>
					
						<form method="POST">
							<div class="grid-item">
								<?php 
									// The password success message will be displayed letting the user know the password was successfully changed 
									echo "<span class='success'>" . $password_success_msg . "</span>";
									
									// Message will be displayed if the password change was unsuccessful
									echo "<span class='error-message'>" . $password_err_msg . "</span>";
								?>
								<label for="log-username"><span class="required"> * </span> Username </label>
									<input type="text" id="log-username" name="log-username">
										<?php 
											echo "<span class='error-message'>" . $entered_username_err_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="current-password"><span class="required"> * </span>	Current password </label>
									<input type="text" id="current-password" name="current-password">
										<?php 
											echo "<span class='error-message'>" . $current_password_err_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="new-password"><span class="required"> * </span> New password </label>
									<input type="text" id="new-password" name="new-password">
										<?php 
											echo "<span class='error-message'>" . $new_password_err_msg . "</span>";
										?>
							</div>

							<div class="grid-item">
								<input type="submit" class="button" value="Submit">
								<input type="reset" class="button" value="Clear">
							</div>
						</form>
					</div>
				</div>		
			</main>
		
		<?php
			// Include the footer
			include_once "footer.php";
		?>
	</body>
</html>