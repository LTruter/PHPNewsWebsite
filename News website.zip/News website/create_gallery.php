<!DOCTYPE html>
<!--
Filename: create_gallery.php
Author: Lario Truter
Created: 29 November 2023
Description: The user can input a name and create a gallery.
-->

<?php
	session_start();
?>
<html>
	<head>		
		<title> Create Gallery </title>
		
		<link rel="stylesheet" href="CSS/stylesheet.css">
	</head>
	
	<body>
		<?php
			// Include the header
			include_once "header.php";
		
		    // require_once is used to make sure that if the specific file cannot be included, then it will cause a fatal error
			// require_once is used because I'm not going to include it again
			require_once "user_exists.php";
			require_once "db_connection.php";
			require_once "logout.php";
		
			// Define error message variables
			$gallery_name_err_msg = "";	
			
			// Define gallery created successfully message
			$gallery_created_msg = "";
		
		
			if($_SERVER["REQUEST_METHOD"] == "POST") {
				
				// Checks if gallery name is NOT empty
				if(!empty($_POST["gallery-name"])){
					
					// Store to variables
					$gallery_name = $_POST["gallery-name"];
					$username = $_SESSION["username"];
					
					// Check if the gallery name already exists
					// Selects the gallery name from created_galleries where it is equal to the gallery_name that was input in the form
					$check_stmt = $conn->prepare("SELECT gallery_name FROM created_galleries WHERE gallery_name = ?");
					
					// Binds the form input variable to the prepared statement
					$check_stmt->bind_param("s", $gallery_name);
					
					// Executes the prepared statement
					$check_stmt->execute();
					
					// Store the result to a variable
					$result = $check_stmt->get_result();
					
					// Checks if there are no rows that match the gallery name
					if($result->num_rows == 0) {
				
						// Prepare and bind the SQL statement
						$insert_stmt = $conn->prepare("INSERT INTO created_galleries (gallery_name, username) VALUES (?, ?)");
						
						$insert_stmt->bind_param("ss", $gallery_name, $username);
						
						// Checks if the statement was executed successfully
						if ($insert_stmt->execute()) {
							
							$gallery_created_msg = "Gallery created successfully!";
							
						} else {
							
							// echo "Error: " . $insert_stmt->error;
							
						}
						
						// Close the insert statement 
						$insert_stmt->close();
						
					} else {
					
						// Stores the string to the variable
						$gallery_name_err_msg = "Gallery name already exists";
					
						// Close the check statement
						$check_stmt->close();
					}
					
				} else {
					
					// Stores the string to the variable
					$gallery_name_err_msg = "Gallery name is required";
				}
			}
		
			// Close the database connection
			$conn->close();
		?>
		
			<main class="page-height">
				<div class="grid-container">
					<div class="form-outline">
						<h2> Create Gallery </h2>
							<?php
								echo "<div class='success'>" . $gallery_created_msg . "</div>";
							?>
						
							<form method="POST">
								<div class="grid-item">
									<label for="gallery-name"><span class="required"> * </span> Gallery name: </label>
										<input type="text" name="gallery-name">
											<?php
												echo "<span class='error-message'>" . $gallery_name_err_msg . "</span>";
											?>
								</div>	
								
								<div class="grid-item">
									<input type="submit" class="button" value="Create gallery">
								</div>
							</form>
					</div>
				</div>
			</main>
		<?php
			// Include the footer
			include_once "footer.php";
		?>
	</body>
</html>
