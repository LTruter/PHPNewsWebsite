<?php
/*
Filename: db_connection.php 
Author: Lario Truter
Created: 29 November 2023
Description: Creates a connection to the database.
*/

	// Store database information to variables
	$hostname = "localhost";
	$dbusername = "ODBC";
	$dbpassword = "";
	$dbname = "users";
			
	// Create a connection to the database
	$conn = new mysqli($hostname, $dbusername, $dbpassword, $dbname);
			
	// If statement to check if the connection was successful
	if($conn->connect_error){
			
		// die("Connection error: " . $conn->connect_error);
			
	} else {
			
		// echo "Connection successful";
				
	}

?>