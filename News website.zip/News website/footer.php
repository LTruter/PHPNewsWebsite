<!--
Filename: footer.php
Author: Lario Truter
Created: 01 December 2023
Description: The footer for the page after the user is logged in.
-->

<footer>
	<nav>
		<div id="my-account"><u><b> My Account: </b></u></div>
		<ul>
			<li><a href="change_password.php" class="footer-links"> Change password </a></li>
			
			<!-- Logout button -->
			<form method="POST">
				<li><input type="submit" id="logout" class="footer-links" name="logout" value="Logout"></li>
			</form>
		</ul>
	</nav>
	
	<div id="copyright">
        &copy; Lario Truter 2023
    </div>
</footer>