<!DOCTYPE html>
<!--
Filename: galleries_page.php
Author: Lario Truter
Created: 29 November 2023
Description: Displays the different galleries and their images. Users can also upload images to specific galleries on this page.
-->

<?php
    session_start();
?>
<html>
	<head>		
		<title> Galleries </title>
	
		<link rel="stylesheet" href="CSS/stylesheet.css">
		<style>		
			/* Text that will display if there's no galleries to display */
			.no-galleries{
				font-family: arial;
				font-size: 22px;
				text-align: center;
				margin-top: 30%;
				margin-bottom: 30%;
			}
		
			/* Styles the gallery name */
			.gallery-name{
				text-align: center;
				color: #808080; 
			}
		
			/* Styles the gallery image */
			.gallery-image{
				height: 150px;	/* By only setting the height value the width is auto adjusted */
				padding: 2px;				
			}
			
			/* Stylies the form to upload image */
			.form-upload{
				margin-top: 20px;
				text-align: center;
			}
			
			/* Positioning of the upload button */
			.upload-btn{
				margin-top: 10px;
				margin-bottom: 40px;
			}
		</style>
	</head>

	<body>
		<?php
			// Include the header
			include_once "header.php";
		
			// require_once is used to make sure that if the specific file cannot be included, then it will cause a fatal error
			// require_once is used because I'm not going to include it again
			require_once "user_exists.php";
			require_once "db_connection.php";
			require_once "logout.php";
			
			// Define the error message variable
			$image_err_msg = "";
			
			// Checks that both the values are set
			if(isset($_FILES["image_upload"]["tmp_name"]) && isset($_FILES["image_upload"]["size"])) {
			
				// The $_FILES global array (This is where images uploaded in the form would be stored) 
				// "image_upload" is the array that stores all the data about the image that was uploaded that's stored in $_FILES
				// Retrieve the value that we want from the associative array called "image_upload"
				$image_tmp_name = $_FILES["image_upload"]["tmp_name"];
				$file_size = $_FILES["image_upload"]["size"];
			
				// Checks that the POST method was used and image_tmp_name is NOT empty and file_size is greater than 0
				// By checking that image_tmp_name is NOT empty and file_size is greater than 0, it adds an extra layer of security
				if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($image_tmp_name) && $file_size > 0) {
					
					// Stores the gallery_id value of the gallery where the image was uploaded and submitted
					$gallery_id = $_POST["gallery_id"];
					
					// SELECTS gallery_name from created_galleries where the gallery_id matches the $gallery_id variable and stores the result
					$gallery_name_query = $conn->query("SELECT gallery_name FROM created_galleries WHERE gallery_id = $gallery_id");
					
					// Fetches a row from the result as an associative array
					$gallery_name_row = $gallery_name_query->fetch_assoc();
					
					// Stores the value of the gallery_name to a varaible
					$gallery_name = $gallery_name_row["gallery_name"];

					// Define the upload directory based on gallery name
					$upload_dir = "Uploads/Galleries/" . $gallery_name;

					// Check if the directory does not exist and create it if needed
					if (!is_dir($upload_dir)) {
						
						// mkdir(the directory I want to create, 0755 = gives the directory "read, write and execute permissions", 
						// true = will create the directory and its parent directories(if necessary) is used to create a directory
						mkdir($upload_dir, 0755, true);
						
					}
					
					// Access the name value from "image_upload" in the $_FILES global array
					$image_name = $_FILES["image_upload"]["name"];
					
					// pathinfo returns info about a file path
					// PATHINFO_EXTENSION tells pathinfo to return only the file extension part of the path from $image_name 
					$image_extension = pathinfo($image_name, PATHINFO_EXTENSION);

					// Give the image a unique name by including the unix timestamp
					$image_name = $gallery_name . "_" . time() . "." . $image_extension;

					// Construct the full path to the uploaded image
					$image_path = $upload_dir . "/" . $image_name;

					// Checks if the image was moved to the directory where you will be storing the uploaded images
					// move_uploaded_file(takes the tmp_name, the directory where you want to move the image to)
					// tmp_name is the path to the temporary location of the image when it was first uploaded 
					if (move_uploaded_file($image_tmp_name, $image_path)) {
						
						// Insert the image information into the gallery_images table
						$insert_sql = "INSERT INTO gallery_images (gallery_img_path, gallery_id) VALUES ('$image_path', $gallery_id)";
						
						// Query the sql statement
						$conn->query($insert_sql);
						
						// Redirect to the same page to refresh the page
						header("Location: galleries_page.php");
						
						// Stops all code from running after the page has been redirected
						exit();
					
					} else {
						
						// echo "Failed to move image file to directory.";
						
					}
					
					// Close the database connection
					$conn->close();
					
				} else {
					
					$image_err_msg = "No image was selected";
				
				}
			}

			// SQL to SELECT gallery_id, gallery_name FROM created_galleries
			$sql = "SELECT gallery_id, gallery_name FROM created_galleries";
			
			// Query the sql statement and store the result
			$gallery_info = $conn->query($sql);

			// Check if there are no galleries
			if ($gallery_info->num_rows == 0) {
				
				echo "<div class='no-galleries'> No Galleries Yet </div>";
				
			} else {
				
				// While there are still rows to fetch from $gallery_info, the code inside the loop will run, and each row will be fetched as an associative array and stored in the variable $gallery_row.
				while ($gallery_row = $gallery_info->fetch_assoc()) {
					
					// Stores the gallery_id and gallery_name value from the fetched row to a variable
					$gallery_id = $gallery_row['gallery_id'];
					$gallery_name = $gallery_row['gallery_name'];
				
					// Gallery name
					echo "<div class='gallery-name'>";
					echo "    <h1> Gallery: $gallery_name </h1>";
					echo "</div>";

					// SQL statement to SELECT every row FROM gallery_images WHERE gallery_id = $gallery_id variable
					$images_sql = "SELECT * FROM gallery_images WHERE gallery_id = $gallery_id";
					
					// Store the query results
					$images_result = $conn->query($images_sql);

					// While there are still rows to fetch from $images_result, the code inside the loop will run, and each row will be fetched as an associative array and stored in the variable $image_row.
					while ($image_row = $images_result->fetch_assoc()) {
						
						// gallery_img_path value is stored to the variable
						$image_path = $image_row['gallery_img_path'];
						
						// Displays the image using the $image_path variable as the source
						echo "<img src='$image_path' class='gallery-image' alt='Gallery Image'>";
						
					}

					echo "<div class='form-upload'>";
					
					// (enctype="multipart/form-data") is used when there is a file input field
					echo "    <form method='POST' enctype='multipart/form-data'>";
				
					// Since the form is part of the while loop, when the form is submitted the current gallery_id can be stored in the $_POST array so that the uploaded image is linked to the current gallery_id
					echo "        <input type='hidden' name='gallery_id' value='$gallery_id'>";
					
					echo "        <div>";
					echo "            <label for='image_upload'> Upload Image: </label>";
					echo "                <input type='file' name='image_upload' id='image_upload' class='button'>";
					echo "                    <span class='error-message'>" . $image_err_msg . "</span>";
					echo "        </div>";
					
					echo "        <div class='upload-btn'>";
					echo "            <input type='submit' value='Upload' class='button'>";
					echo "        </div>";
					echo "    </form>";
					echo "</div>";
				}
			}
		
			// Include the footer
			include_once "footer.php";
		?>
	</body>
</html>
