<!--
Filename: header.php
Author: Lario Truter
Created: 01 December 2023
Description: The header for the page after the user is logged in.
-->

<header>
    <h1 id="site-name"> News Today</h1>
    <nav>
		<a href="home_page.php" class="header-links"> Home </a>
		<a href="galleries_page.php" class="header-links"> Galleries </a>
		<a href="Create_gallery.php" class="header-links"> Create Gallery </a>
		<a href="news_sharing.php" class="header-links"> Share current news </a>
    </nav>
</header>





