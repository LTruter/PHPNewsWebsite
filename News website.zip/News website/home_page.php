<!DOCTYPE html>
<!--
Filename: home_page.php
Author: Lario Truter
Created: 29 November 2023
Description: Home page for my website and displays current news shared by the users. Users can also leave comments on the articles.
-->

<?php
    session_start();    // Session must start before the HTML
?>
<html>
	<head>		
		<title> Home </title>
		
		<link rel="stylesheet" href="CSS/stylesheet.css">
		<style>
			/* Styling for the grid-items */
			.grid-item{
				text-align: center;
				margin-left: 5%;
				margin-right: 5%;
			}
			
			/* Styling for the article heading */
			.article-heading{
				margin-top: 10%;
			}
			
			/* Styling for the article image */
			.article-image {
				height: 400px;
			}
			
			/* Styling for the empty page */
			main{
				font-family: Arial;
				font-size: 22px;
			}
		</style>
	</head>

	<body>
		<?php
			// Include the header
			include_once "header.php";
		
			// require_once is used to make sure that if the specific file cannot be included, then it will cause a fatal error
			// require_once is used because I'm not going to include it again
			require_once "user_exists.php";
			require_once "db_connection.php";
			require_once "logout.php";

			// Defining the default value for the error message variable
			$comment_error_msg = "";


			// Checks if the request method is POST and if the comment form was submitted
			if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["comment_submit"])) {
				
				// Checks if the comment input was NOT empty when the comment was submitted
				if (!empty($_POST["comment_text"])) {
					
					// Sanitize the variables
					$article_id = mysqli_real_escape_string($conn, $_POST['article_id']);
					$comment_text = mysqli_real_escape_string($conn, $_POST['comment_text']);
					$username = $_SESSION["username"]; 

					// sql statement
					$sql = "INSERT INTO user_comments (article_id, username, comment_text) VALUES (?, ?, ?)";
					
					// Prepare the sql statement
					$stmt = $conn->prepare($sql);
					
					// Bind the variables to the parameters
					$stmt->bind_param("sss", $article_id, $username, $comment_text);

					// Checks if the prepared statement was executed successfully
					if ($stmt->execute()) {
						
						// Redirects to the same page (reloads the page so that the new comment is displayed
						header("Location: home_page.php");
						
						exit();
						
					} else {
						
						// echo "Error: Unable to insert comment.";
						
					}
					
					// Close the prepared statement
					$stmt->close();
					
				} else {
					
					// The string is stored to the error message variable
					$comment_error_msg = "Comment must contain a value";
					
				}
			}


			// SELECT all relevant columns from my table and ORDER BY article_date DESC so that the most recent articles are displayed first
			$sql = "SELECT article_id, article_heading, article, article_type, article_date, image_path, article_url, username FROM news_articles ORDER BY article_date DESC";

			// Stores the query results to the variable
			$result = $conn->query($sql);

			// Checks if query was successful
			if ($result) {

				// Checks if the number of rows stored in the variable is greater than 0
				if ($result->num_rows > 0) {

					// The while loop fetches one row at a time from the $result variable
					// Each fetched row is stored as an associative array in the $row variable
					// The loop displays the contents of each row until there are no more rows to fetch    
					while ($row = $result->fetch_assoc()) {

						echo"<main>";
						echo "	<div class='grid-container'>";
						echo "		<div class='grid-item'>";
						
						// htmlspecialchars converts special characters to their html entities, which prevents XSS(Cross-site scripting) by ensuring the user input is not interpretted as html/javascript 
						// htmlspecialchars is mainly used when outputting user input
						// Article heading
						echo "			<h2 class='article-heading'>" . htmlspecialchars($row["article_heading"]) . "</h2>";
						echo "		</div>";
						
						// Article
						echo "	<div class='grid-item'>";
						echo "		<p>" . htmlspecialchars($row["article"]) . "</p>";
						echo "	</div>";
						
						// Article type
						echo "	<div class='grid-item'>";
						echo "		<p><strong> News type: </strong>" . $row["article_type"] . "</p>";
						echo "	</div>";
						
						// Article date
						echo "	<div class='grid-item'>";
						echo "		<p><strong> Article published on: </strong>" . $row["article_date"] . "</p>";
						echo "	</div>";
						
						// Article image
						echo "	<div class='grid-item'>";
						echo "		<img src='" . $row["image_path"] . "' class='article-image' alt='Article Image'>";
						echo "	</div>";
						
						// Article url
						echo "	<div class='grid-item'>";
						echo "		<p><strong> Article URL: </strong><a href='" . htmlspecialchars($row["article_url"]) . "'>" . $row["article_url"] . "</a></p>";
						echo "	</div>";
						
						// Username
						echo "<div class='grid-item'>";
						echo "		<p><strong> Shared by: </strong>" . htmlspecialchars($row["username"]) . "</p>";
						echo "</div>";

						// Stores the id for the current article being displayed (must be done in the while loop because this needs to be a part of the loop to get the article_id)
						$article_id = $row["article_id"];

						// Selects all comments linked to this article_id (the header() redirect to the same page will work like a refresh when the comment button is clicked)
						$comment_query = "SELECT * FROM user_comments WHERE article_id = '$article_id' ORDER BY date_posted DESC";

						// Stores the results of the query
						$comment_result = $conn->query($comment_query);

						// Checks the number of rows stored to the result
						if ($comment_result->num_rows > 0) {

							// Comments heading
							echo "<div class='grid-item'>";
							echo "	<h3> Comments: </h3>";
							echo "</div>";

							// The while loop displays the contents of each row until there are no more rows to fetch and store as associative arrays    
							while ($comment_row = $comment_result->fetch_assoc()) {

								// User comments
								echo "<div class='grid-item'>";
								echo "	<p><strong>" . $comment_row["username"] . ":</strong> " . htmlspecialchars($comment_row["comment_text"]) . " - " . $comment_row["date_posted"] . "</p>";
								echo "</div>";
							}
							
						} else {
							
							echo "<div class='grid-item'>";
							echo 	"No comments yet.";
							echo "</div>";
						}

						// Comment form for each article
						echo "<form method='POST'>";
						
						echo "	<div class='grid-item'>";
						
						// The hidden input field containing the current article_id will be submitted with the form data and stored in the $_POST array on form submission
						echo "		<input type='hidden' name='article_id' value='" . $article_id . "'>";
						
						// Comment box
						echo "			<textarea id='comment_text' name='comment_text' rows='4' cols='50'></textarea>";

						// Display the comment error message if it's empty
						echo "			<span class='error-message'>" . $comment_error_msg . "</span>";
						echo "<br>";
						echo "	</div>";
						
						// Comment button
						echo "	<div class='grid-item'>";
						echo "			<input type='submit' id='comment_submit' class='button' name='comment_submit' value='Comment'>";
						echo "		</form>";
						echo "	</div>";
						
						echo "	</div>";
						echo "</main>";
					}
					
				} else {

					// Message will be stored if there's no news available to be displayed
					$empty_page = "No News Yet";
				}
			}

			// Close the database connection
			$conn->close();
			
			
			// Checks if the variable is NOT empty
			if(!empty($empty_page)){
				
				echo "<main class='page-height'>";
				echo $empty_page;
				echo "</main>";
				
			}
		
			// Include the footer
			include_once "footer.php";
		?>
	</body>
</html>
