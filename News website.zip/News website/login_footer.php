<!--
Filename: login_footer.php
Author: Lario Truter
Created: 04 December 2023
Description: The footer for the page before the user is lgged in.
-->

<footer id="login-footer">	
	<div>
        &copy; Lario Truter 2023
    </div>
</footer>