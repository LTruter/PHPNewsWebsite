<!--
Filename: login_header.php
Author: Lario Truter
Created: 04 December 2023
Description: The header for the page before the user is logged in.
-->

<header>
    <h1 id="login-site-name"> News Today</h1>
</header>