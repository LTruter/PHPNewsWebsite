<!DOCTYPE html>
<!--
Filename: login_page.php
Author: Lario Truter
Created: 29 November 2023
Description: The user can input their username and password and log in to the site where they will be redirected to the home page.
-->
<html>
	<head>		
		<title> Login </title>
		
		<link rel="stylesheet" href="CSS/stylesheet.css">
	</head>
	
	<body>		
		<?php	
			// Include the header
			include_once "login_header.php";
			
			// Requires the database connection
			require_once "db_connection.php";
			
			// Define the variable
			$login_error_msg = "";
			
			// If statement checks if the user has submited a form before running. This prevents it from accidently running when the user is just viewing the page
			// $_SERVER is the superglobal array that contains information about the server.
			// Access the server array to see the request method and see if it evaluates to the POST method
			if($_SERVER["REQUEST_METHOD"] == "POST"){	
				
				// Save the input values to variables
				$entered_username = $_POST["log-username"];
				$entered_password = $_POST["log-password"];
				
				// SQL statement to see if the username and password match
				$sql = "SELECT * FROM user_regist WHERE username = ? AND password = ?";
				
				// Prepare the sql statement
				$stmt = $conn->prepare($sql);
				
				// Checks if the statement was prepared correctly
				if($stmt){
				
					// Bind the parameters to the prepared statement
					$stmt->bind_param("ss", $entered_username, $entered_password);
		
					// Stores the result to a variable
					$query_result = $stmt->execute();
					
					// Checks if the prepared statement was executed successfully
					// execute() is used for prepared statements
					if($query_result){
						
						// get_result() is used to get the result of a SELECT query
						$result = $stmt->get_result();
						
						// If statement checks to see if only one row meets the query requirements (This prevents it from matching the username of one account and password of another)
						if($result->num_rows == 1) {
							
							// Starts the session
							session_start();
							
							// fetch_assoc() fetches the current row as an associative array and will do the same for the next row in get_result(if there is more) if it's called again
							$user_data = $result->fetch_assoc();
							
							// Stores the value of username from the associative array to a variable called username in the $_SESSION super global array
							$_SESSION['username'] = $user_data['username'];
							
							// header() is used to give instructions to the browser. header(Location header tells the browser where to redirect to)
							header("Location: home_page.php");
							
							// exit makes sure no further code is executed after the redirect
							exit();
							
						} else {
							
							$login_error_msg = "Invalid username or password <br>";
							
						}
						
					} else {
					
						// echo "ERROR! Statement failed to execute: " . $stmt->error . "<br>";	
					
					}
					
					// Prepared statement must be closed
					$stmt->close();
									
				} else {
				
					// echo "Error! Statement failed to prepare: " . $conn->error . "<br>";
				
				}	
			} 
			
			// Database connection must be closed
			$conn->close();
		?>
	
		<main class="page-height">
			<div class="grid-container">
				<div class="form-outline">
					<h2> Log in: </h2>
								
					<form method="POST">
						<div class="grid-item">
							<?php
								echo "<span class='error-message'>" . $login_error_msg . "</span>";
							?>
							<label for="log-username"><span class="required"> * </span> Username: </label>
								<input type="text" id="log-username" name="log-username">
						</div>
										
						<div class="grid-item">
							<label for="log-password"><span class="required"> * </span> Password: </label>
								<input type="password" id="log-password" name="log-password">		
						</div>

						<div class="grid-item">
							<input type="submit" class="button" value="Log in">
							<input type="reset" class="button">
						</div>
					</form>
					
					Don't have an account? <br> Click here to return to <a href="registration_page.php"> Registration page </a>
				</div>
			</div>
		</main>
			<?php
				// Include the footer
				include_once "login_footer.php";
			?>
	</body>
</html>