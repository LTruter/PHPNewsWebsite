<?php
/*
Filename: logout.php
Author: Lario Truter
Created: 29 November 2023
Description: Checks if the logout button was clicked. If it was, the user is logged out and redirected to the login page. 
*/

	// Checks if the "logout"(the name attribute value) key is set in the $_POST array
	// "logout" key will only be set in the $_POST array if the logout button is clicked
	if(isset($_POST["logout"])) {
				
		// Destroys the session
		session_destroy();
				
		// Redirects the user back to the login page
		header("Location: login_page.php");
				
		// Terminates the script's execution to prevent any further code from being executed
		exit();
				
	}
?>