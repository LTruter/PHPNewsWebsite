<!DOCTYPE html>
<!--
Filename: news_sharing.php
Author: Lario Truter
Created: 29 November 2023
Description: User can submit news articles using the form.
-->

<?php
	session_start();		// Session must start before the html
?>
<html>
	<head>		
		<title> News Sharing </title>
		
		<link rel="stylesheet" href="CSS/stylesheet.css">
	</head>
	
	<body>
		<?php
			// Include the header
			include_once "header.php";
		
			// require_once is used to make sure that if the specific file cannot be included, then it will cause a fatal error
			// require_once is used because I'm not going to include it again
			require_once "user_exists.php";
			require_once "db_connection.php";
			require_once "logout.php";
			
		
			// Defining the error message variables
			$article_heading_error_msg = "";
			$article_error_msg = "";
			$article_type_error_msg = "";
			$article_date_error_msg = "";
			$article_image_error_msg = "";
			$article_url_error_msg = "";
			
			// Defining the variable that will prevent the form from being submitted
			$incorrect_input = false;
			
			// Defining news shared successfully variable
			$news_successful_msg = "";
			
			if($_SERVER["REQUEST_METHOD"] == "POST"){					
						
				// Save the input data to variables
				$article_heading = $_POST["article-heading"];
				$article = $_POST["article"];
				$article_type = $_POST["article-type"];
				$article_date = $_POST["article-date"];
				$article_url = $_POST["article-url"];
				// Get the uploaded image file and its' information
				// $article_image stores information related to the image which will allow me to process or manipulate the file
				$article_image = $_FILES["article-image"];
				
				// Store username value from $_SESSION array to the variable
				$username = $_SESSION["username"];
						
				// Validation for the article heading
				// Checks if article heading is empty
				if(empty($article_heading)){
				
					$article_heading_error_msg = "Article heading is required";
				
					$incorrect_input = true;
					
				} else {
				
					// Checks if the string length of the article heading is longer than 255
					if(strlen($article_heading) > 255) {
					
						$article_heading_error_msg = "Article heading input can not be longer than 255 characters";
					
						$incorrect_input = true;
						
					}
				}


				// Validation for the article
				// Checks if article is empty
				if(empty($article)) {
				
					$article_error_msg = "Article is required";
				
					$incorrect_input = true;
					
				}
				
				
				// Define an array with all the options for the article type drop down list
				$types_of_articles = ["Sport", "Business", "Entertainment"];
				
				// Validation for the article type
				// Checks if article type is empty
				if(empty($article_type)) {
				
					$article_type_error_msg = "Article type is required";
				
					$incorrect_input = true;
				
				} else {
				
					// Checks if the option the user chose is NOT one of the options in the provided array
					if(!in_array($article_type, $types_of_articles)) {
					
						$article_type_error_msg = "Must select one of the valid article type options";
						
						$incorrect_input = true;
					
					}
				}
				
				
				// Validation for the article date
				// Checks if article date is empty
				if(empty($article_date)) {
				
					$article_date_error_msg = "Article date is required";
				
					$incorrect_input = true;
				
				} else {
				
					// Checks if the pattern specified does NOT match the variable
					if(!preg_match('/^\d{4}-\d{2}-\d{2}$/', $article_date)){
					
						// Check what the article_date is that failed to match
						// var_dump($article_date);
						
						$article_date_error_msg = "Please input the article date in the YYYY-MM-DD format";
						
						$incorrect_input = true;
					
					} else {
						
						// strtotime converts the date into the unix timestamp (number of seconds passed since January 1, 1970, 00:00:00)
						// "today" is a keyword in strtotime which gets the current date (just the date not the time)
						// Check if the current date is less than the $article_date (which would mean that the article that the user is sharing hasn't been published yet)
						if(strtotime("today") < strtotime($article_date)){
							
							/* 
							// Dump the time strings so I can check that it's working correctly
							$today = strtotime("today");
							$input_article_date = strtotime($article_date);
							
							echo "Current date: " . var_dump($today) . "<br>";
							echo "User date of birth: " . var_dump($input_article_date) . "<br>"; 
							*/
						
							$article_date_error_msg = "Date published can not be greater than the current date";
						
							$incorrect_input = true;
							
						}					
					}
				}
							
				
				// Validation for the article image
				// tmp_name is the temporary name the file is given while it's being stored temporarily during the upload process
				// Checks if the tmp_name is empty or the size is equal to 0
				if(empty($article_image["tmp_name"]) || $article_image["size"] == 0) {
				
					$article_image_error_msg = "Article image is required";
					
					$incorrect_input = true;
				
				}
				
				
				// Validation for article url
				// Checks if article url is empty
				if(empty($article_url)) {
				
					$article_url_error_msg = "Article url is required";
					
					$incorrect_input = true;
				
				} else {
				
					// filter_var(the variable to filter, THE_FILTER_TO_APPLY) allows you to do specific checks on variables and returns true if it meets the requirements
					// FILTER_VALIDATE_URL checks if the variable contains a valid url
					// Checks if the url is NOT valid
					if(!filter_var($article_url, FILTER_VALIDATE_URL)) {
					
						// Check what the article_url is and why it's invalid
						// var_dump($article_url);
					
						$article_url_error_msg = "Article url is not valid";
						
						$incorrect_input = true;
					
					}
				}
				
				
				// If any of the validations are failed $incorrect_input will evaluate to true and the if statement will only run if $incorrect_input is NOT true
				if(!$incorrect_input) {
				
					
					// Create the directory where the uploaded images will be stored in the same directory where my code is stored
					// The $article_type variable stores the specific type of news and this will be the specific subfolder that the $article_image will be stored in
					// The path will be Uploads->News->The type of news->the image
					$upload_dir = "Uploads/News/" . $article_type;

					// Checks if the directory does NOT exist and if it doesn't then it will create the directory otherwise it will just ignore the if statement
					// is_dir(checks if the given path is a directory)
					if (!is_dir($upload_dir)) {

						// mkdir(the directory I want to create, 0755 = gives the directory "read, write and execute permissions", 
						// true = will create the directory and its parent directories(if necessary) is used to create a directory
						mkdir($upload_dir, 0755, true);
								
					} 
								
					// Stores the path to the temporary location of the image when it was first uploaded 
					$image_tmp_name = $article_image["tmp_name"];
					
					
					// $image_name contains the file path or file name
					$image_name = $article_image["name"];
					
					// pathinfo returns info about a file path
					// PATHINFO_EXTENSION tells pathinfo to return only the file extension part of the path from $image_name 
					$image_extension = pathinfo($image_name, PATHINFO_EXTENSION);
					
					// Give the image a unique name by including the unix timestamp
					$image_name = $article_type . time() . "." . $image_extension;
											
					// Move the image to the directory where I will be storing the uploaded images
					// By concatenating $upload_dir and $image_name, I've created the full path to the uploaded image
					$image_path = $upload_dir . "/" . $image_name; 

					// Checks if the image was NOT moved to the directory where you will be storing the uploaded images
					// move_uploaded_file(takes the tmp_name, the directory where you want to move the image to)
					// tmp_name is the path to the temporary location of the image when it was first uploaded 
					if (!move_uploaded_file($image_tmp_name, $image_path)) {
								
						// echo "Failed to move image file to directory";
									
					}
					
					// SQL query  
					$sql = "INSERT INTO news_articles(article_heading, article, article_type, article_date, image_path, article_url, username) 
							VALUES(?, ?, ?, ?, ?, ?, ?)";
						
					// Prepare the query
					$stmt = $conn->prepare($sql);
						
					//If statement checks if the statement was prepared correctly
					if($stmt){
							
						// Bind the parameters to the query
						$stmt->bind_param("sssssss", $article_heading, $article, $article_type, $article_date, $image_path, $article_url, $username);

								
						if($stmt->execute()){
									
							$news_successful_msg = "News shared!";
										
						} else {
									
							// echo "Data failed to insert: " . $stmt->error; 
									
						}
					} else {
								
						// echo "ERROR! Statement failed to prepare: " . $conn->error;
								
					}
					
					// Close the prepared statement
					$stmt->close();
				
				}					
			}
			
			// Close the database connection
			$conn->close();
		?>	
		
		
		<main class="page-height">
			<div class="grid-container">
				<div class="form-outline">
					<h2> Share a news article: </h2>
						<?php
							echo "<div class='success'>" . $news_successful_msg . "</div>";
						?>
						
						<form method="POST" enctype="multipart/form-data">	<!-- (enctype="multipart/form-data") is used when there is a file input field -->
							<div class="grid-item">
								<label for="article-heading"><span class="required"> * </span> Article heading: </label>
									<input type="text" id="article-heading" name="article-heading">
										<?php
											echo "<span class='error-message'>" . $article_heading_error_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="article"><span class="required"> * </span> Article: </label> <br>
									<textarea id="article" name="article" rows="4" cols="50" ></textarea>
										<?php
											echo "<span class='error-message'>" . $article_error_msg . "</span>";
										?>
							</div>		
							
							<div class="grid-item">
								<label for="article-type"><span class="required"> * </span> Article type: </label>
									<select id="article-type" name="article-type" >
										<option value=""> Select article type </option>
										<option value="Sport"> Sport </option>
										<option value="Business"> Business </option>
										<option value="Entertainment"> Entertainment </option>
									</select>
										<?php
											echo "<span class='error-message'>" . $article_type_error_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="article-date"><span class="required"> * </span> Date published: </label>
									<input type="date" id="article-date" name="article-date">
										<?php
											echo "<span class='error-message'>" . $article_date_error_msg . "</span>";
										?>
							</div>

							<div class="grid-item">
								<label for="article-image"><span class="required"> * </span> Article cover image: </label>
									<input type="file" id="article-image" name="article-image">
										<?php
											echo "<span class='error-message'>" . $article_image_error_msg . "</span>";
										?>
							</div>

							<div class="grid-item">
								<label for="article-url"><span class="required"> * </span> Article url: </label>
									<input type="text" id="article-url" name="article-url">
										<?php
											echo "<span class='error-message'>" . $article_url_error_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<input type="submit" class="button" value="Upload">
								<input type="reset" class="button" value="Clear">
							</div>
						</form>
				</div>
			</div>
		</main>
		<?php
			// Include the footer
			include_once "footer.php";
		?>
	</body>
</html>