<!DOCTYPE html>
<!--
Filename: registration_page.php
Author: Lario Truter
Created: 29 November 2023
Description: User can input their details in the form and create an account.
-->
<html>
	<head>	
		<title> Registration </title>
		
		<link rel="stylesheet" href="CSS/stylesheet.css">
		
		<style>
			.success{
				margin-bottom: 10px;
			}		
		</style>		
	</head>
	
	<body>
		<?php
			// Include the header
			include_once "login_header.php";
		
			// require_once is used to make sure that if the specific file cannot be included, then it will cause a fatal error
			// require_once is used because I'm not going to include it again
			require_once "db_connection.php";
			
			// These variables have to be defined because they are refernced outside of my if statement, so even if my if statement doesn't run the variables still need a value
			// Define the variable that will store the specific error message-box
			$name_error_msg = "";
			$surname_error_msg = "";
			$gender_error_msg = "";
			$date_of_birth_error_msg = "";
			$email_error_msg = "";
			$contact_no_error_msg = "";
			$username_error_msg = "";
			
			// Defining the registration success message variable
			$regist_msg = "";

			// If statement that will prevent the code inside from running until the form has been submitted
			if($_SERVER["REQUEST_METHOD"] == "POST") {
					
				// Save the input values to variables
				$name = $_POST["first_name"];
				$surname = $_POST["last_name"];
				$gender = $_POST["gender"];
				$date_of_birth = $_POST["date_of_birth"];
				$email = $_POST["email"];
				$contact_no = $_POST["contact_number"];
				$username = $_POST["create_username"];
				
				// $email_newsletter is optional, so if it was checked then the value of 1 will be stored (checkbox has value of 1), if not then the value of 0 is stored
				if(isset($_POST["email_newsletter"])) {
				
					$email_newsletter = $_POST["email_newsletter"];
				
				} else {
				
					$email_newsletter = 0;
				
				}
				
								
				// Define variable that will prevent the form from being submitted to database if the variable is true
				$incorrect_input = false;
				
				
				// Validate the name input
				// If statement checks if the name variable is empty
				// empty() checks if the variable is empty
				if(empty($name)) {
					
					// The specific error message is saved to the variable because it failed this check
					$name_error_msg = "Name is required";
					
					// The variable is set to true if any of the checks are failed
					$incorrect_input = true;
					
				} else {
									
					// ctype_alpha() returns true if all the characters in the string are alphabetic letters
					// If statement to check if ctype_alpha() returns not true
					if(!ctype_alpha($name)) {
					
						$name_error_msg = "Name input can only contain letters";
						
						$incorrect_input = true;

					} else {
					
						// If statement to check if the name variable string length is greater than the character limit
						// strlen() is used to find the string length
						if(strlen($name) > 30) {
						
							$name_error_msg = "Name input can not be longer than 30 characters";
							
							$incorrect_input = true;
						
						} 
					}
				}


				// Validate the surname input
				// If statement checks if the surname variable is empty
				if(empty($surname)){
					
					$surname_error_msg = "Surname is required";
					
					$incorrect_input = true;
					
				} else {
					
					// If statement checks if all the characters in the string are not alphabetic letters
					if(!ctype_alpha($surname)) {
						
						$surname_error_msg = "Surname input can only contain letters";
						
						$incorrect_input = true;
					
					} else {
						
						// // If statement to check if the surname variable string length is greater than the character limit
						if(strlen($surname) > 30) {
					
							$surname_error_msg = "Surname input can not be longer than 30 characters";
					
							$incorrect_input = true;
						
						}
					}
				}
				
				
				// Defining a variable that contains an array with all the gender options
				$gender_options = ["Male", "Female", "Other"];
				
				// Validate the gender input
				// If statement checks if the gender variable is empty
				if(empty($gender)) {
					
					$gender_error_msg = "Gender is required";
					
					$incorrect_input = true;
					
				} else{
					
					// If statement checks if the chosen gender is NOT one of the values in the array
					// in_array checks if a given value exists in an array (in_array(value to check for, array to check))
					if(!in_array($gender, $gender_options)){
						
						$gender_error_msg = "Must select one of the valid gender options";
						
						$incorrect_input = true;
					
					}
				}
				
				
				// Validate the date input
				// If statement checks if the date of birth variable is empty
				if(empty($date_of_birth)) {
					
					$date_of_birth_error_msg = "Date of Birth is required";
					
					$incorrect_input = true;
				
				} else {
				
					// preg_match() checks that the pattern inside is matched in the variable provided
					// (/^) indicates the start of the string, ($/) indicates the end of the string, (\d{4}) indicates that the value should be a digit and 4 characters long, (-) is used as part of the date format
					// If string length is NOT equal to 10 OR the pattern is NOT matched, then the code will be executed
					if(!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_of_birth)){
						
						$date_of_birth_error_msg = "Please input your Date of birth in the YYYY-MM-DD format";
						
						$incorrect_input = true;
					
					} else {
						
						// strtotime converts the date into the unix timestamp (number of seconds passed since January 1, 1970, 00:00:00)
						// "today" is a keyword in strtotime which gets the current date (just the date not the time)
						// Check if the current date is less than the $date_of_birth (which would mean that the person submitting the form hasn't been born yet)
						if(strtotime("today") < strtotime($date_of_birth)){
							
							/* 
							// Dump the time strings so I can check that it's working correctly
							$today = strtotime("today");
							$input_do_birth = strtotime($date_of_birth);
							
							echo "Current date: " . var_dump($today) . "<br>";
							echo "User date of birth: " . var_dump($input_do_birth) . "<br>"; 
							*/
							
							$date_of_birth_error_msg = "Date of Birth can not be greater than the current date";
						
							$incorrect_input = true;
						
						}
					}
				}
				
				
				// Validate the email input
				// If statement checks if the email variable is empty
				if(empty($email)) {
					
					$email_error_msg = "Email is required";
					
					$incorrect_input = true;
				
				} else {
					
					// If statement that checks if the string length of email is longer than 100 characters 
					if(strlen($email) > 100) {
							
						$email_error_msg = "Email can not be longer than 100 characters";
							
						$incorrect_input = true;
					
					} else {
					
						// filter_var(the variable to filter, THE_FILTER_TO_APPLY) allows you to do specific checks on variables and returns true if it meets the requirements
						// FILTER_VALIDATE_EMAIL checks if the variable contains a valid email
						// If statement checks if the email is NOT valid  
						if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
							
							$email_error_msg = "Email must be in the following format: example@gmail.com";
							
							$incorrect_input = true;
						
						}
					}
				}
				
				
				// Validate contact number
				// If statement checks if the contact number variable is empty
				if(empty($contact_no)) {
					
					$contact_no_error_msg = "Contact number is required";
					
					$incorrect_input = true;
				
				} else {
					
					// preg_match checks that the pattern of 10 digits is NOT matched in the variable $contact_no
					// If statement checks if contact number does NOT only contains numbers 
					if(!preg_match('/^\d{10}$/', $contact_no)) {
						
						$contact_no_error_msg = "Contact number must 10 digits";
							
						$incorrect_input = true;
							
					}
				} 	
				
				// Query to check if the username input in the form already exists
				// SELECT all records FROM the user_regist table WHERE the username record matches the username input
				$sql = "SELECT * FROM user_regist WHERE username = '$username'";
				
				// Runs the query using the database connection object and saves the result
				$result = $conn->query($sql);
				
				// Validate the username
				// If statement checks if the username variable is empty
				if(empty($username)) {
					
					$username_error_msg = "Username is required";
					
					$incorrect_input = true;
				
				} else {
					
					// Checks if the number of rows stored to result is greater than 0
					if($result->num_rows > 0) {
						
						$username_error_msg = "Username already exists";
						
						$incorrect_input = true;
					
					} else {
					
						// If statement checks if the username is longer than 30 characters 
						if(strlen($username) > 30) {
							
							$username_error_msg = "Username can not be longer than 30 characters";
							
							$incorrect_input = true;
							
						}
					}					
				}
				
								
				// If statement that redirects the form if $incorrect_input is NOT true
				if(!$incorrect_input){

					// Sanitise the form data
					// mysqli_real_escape_string(the connection object, the variable to sanitise)
					$name = mysqli_real_escape_string($conn, $name);
					$surname = mysqli_real_escape_string($conn, $surname);
					$gender = mysqli_real_escape_string($conn, $gender);
					$date_of_birth = mysqli_real_escape_string($conn, $date_of_birth);
					$email = mysqli_real_escape_string($conn, $email);
					$contact_no = mysqli_real_escape_string($conn, $contact_no);
					$username = mysqli_real_escape_string($conn, $username);
					
					
					// PHPDoc comment
					/**
					 * Generates a random password of a specified length.
					 *
					 * This function uses a predefined set of characters, stored in a variable, to generate a random password.
					 * The characters are shuffled, and a substring of the desired length is extracted.
					 * The resulting substring is shuffled. 
					 * Before being returned it is shuffled again.
					 *
					 * @param int $num_of_char The desired length of the generated password.
					 *
					 * @return string The randomly generated password.
					 */
					function generate_random_password($num_of_char){
											
						// Variable that contains the characters I will be using for my randomly generated password 
						$characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*";
											
						// Now I'll use str_shuffle() to shuffle all the characters in the string and assign the new string back to the variable
						$characters = str_shuffle($characters);
											
						// substr() allows me to extract a portion of a string(the string, the start point (3), number of characters to extract(10)) 
						$random_password = substr($characters, 3, $num_of_char);
											
						// Shuffle the string
						$random_password = str_shuffle($random_password);
											
						// Shuffle the string and return the output
						return str_shuffle($random_password);
					}
							
					// Storing the randomly generated password to the variable
					$password = generate_random_password(10);
					
					// Check that the $password is being generated
					//var_dump($password);
				
					// Inserting the stored form data variables into the database (This is like creating a template, with placeholders(?)) 
					$sql = "INSERT INTO user_regist(first_name, last_name, gender, date_of_birth, email, contact_number, email_newsletter, username, password) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
					
					// Prepare the sql statement (This is like saving the template to the database system so that the placeholders can have values bound to them later) 
					$stmt = $conn->prepare($sql);
				
					// If statement checks if the statement was prepared correctly
					if($stmt) {
						
						// Access the prepared statemnt to bind values to the placeholders parameters(bind_param("first letters of each data type", the variables to be bound))
						$stmt->bind_param("ssssssiss", $name, $surname, $gender, $date_of_birth, $email, $contact_no, $email_newsletter, $username, $password);
						
						// executes the prepared statement with it's bound values and checks if the statement was executed successfully
						// execute() is used for INSERT, UPDATE, DELETE statements
						if($stmt->execute()){
						
							$regist_msg = "Registration successful! A randomly generated password will be emailed to you. Click on the login link below! <br>";
							
						} else {	
						
							// echo "ERROR! Statement failed to execute: " . $stmt->error . "<br>";	
								
						} 
					
					} else {
				
						// echo "Error! Statement failed to prepare: " . $conn->error . "<br>";
				
					}
					
				/*
				// The recipients email address
				$to = $email;
				
				$from = "My database";
				
				$header = "from: " . $from;
				
				// The subject of the email
				$subject = "News Website Registration";
				
				// The randomly generated password
				$email_password = $password;
				
				// The message to be sent
				$message = "Good Day! <br>";
				
				// The full stop before the equals sign will allow me to append this message to the previous message
				$message .= "You have registered for our news website using the email:" . $email;	
				$message .= "This is your password: " . $password;
				
				// Sending the email
				$sent = mail($to, $subject, $message, $header);
				
					// Check if the mail was NOT sent
					if(!$sent){
						
						echo "ERROR sending message";
						
					} else {
						
						echo "Message sent successfully";
						
					}
				*/
				
					// Prepared statement must be closed
					$stmt->close();
				} 

				// Close the database connection
				$conn->close();
			}
		?>
		
		<main class="page-height">	
			<div class="grid-container">
				<div class="form-outline">
					<h2> Registration:</h2>
						<?php
							echo "<div class='success'>" . $regist_msg . "</div>";
						?>
					
						<span class="required"> * Required fields </span>					
					
						<!-- Since no action is specified, the form automatically submits to the same page it originated from -->
						<form method="POST">
							<div class="grid-item">
								<label for="first_name"><span class="required"> * </span> Name: </label>
									<input type="text" id="first_name" name="first_name">
										<?php 
											// Displays the stored error message
											echo "<span class='error-message'>" . $name_error_msg . "</span>";											
										 ?>
							</div>
							
							<div class="grid-item">
								<label for="last_name"><span class="required"> * </span> Surname: </label>
									<input type="text" id="last_name" name="last_name">
										<?php
											echo "<span class='error-message'>" . $surname_error_msg . "</span>";
										?>
							</div>
						
							<div class="grid-item">
								<label for="gender"><span class="required"> * </span> Gender: </label>
									<select id="gender" name="gender">
										<option value=""> Select Gender </option>
										<option value="Male"> Male </option>
										<option value="Female"> Female </option>
										<option value="Other"> Other </option>
									</select>
									
										<?php
											echo "<span class='error-message'>" . $gender_error_msg . "</span>";
										?>
									
							</div>
							
							<div class="grid-item">
								<label for="date_of_birth"><span class="required"> * </span> Date of Birth: </label>
									<input type="date" id="date_of_birth" name="date_of_birth" >
										<?php
											echo "<span class='error-message'>" . $date_of_birth_error_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="email"><span class="required"> * </span> Email: </label>
									<input type="text" id="email" name="email">
										<?php 
											echo "<span class='error-message'>" . $email_error_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="contact_number"><span class="required"> * </span> Contact Number: </label>	
									<input type="text" id="contact_number" name="contact_number">
										<?php
											echo "<span class='error-message'>" . $contact_no_error_msg . "</span>";
										?>
							</div>
							
							<div class="grid-item">
								<label for="email_newsletter"> Receive Newsletters via Email </label>
									<input type="checkbox" id="email_newsletter" name="email_newsletter" value="1">	<!-- The value: "1" will be sent if the checkbox is checked (works the same as the gender drop down list) -->
							</div>

							<div class="grid-item">
								<label for="create_username"><span class="required"> * </span> Create Username </label>
									<input type="text" id="create_username" name="create_username">
										<?php
											echo "<span class='error-message'>" . $username_error_msg . "</span>";
										?>
							</div>
								
							<div class="grid-item">
								<input type="submit" class="button" value="Register">
								<input type="reset" class="button" value="Reset">
							</div>
						</form>
						
					<div> 
						Already have an account?
							<a href="login_page.php">
								Log in
							</a>
					</div>
				</div>
			</div>
		</main>
		
		<?php
			// Include the footer
			include_once "login_footer.php";
		?>
	</body>
</html>