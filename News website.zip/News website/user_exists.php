<?php
/*
Filename: user_exists.php
Author: Lario Truter
Created: 29 November 2023
Description: Checks if the username is set in the SESSION array and if it's not the user is redirected to the login page.
*/

	// Checks if the username key is NOT set in the $_SESSION array
	if(!isset($_SESSION["username"])) {
				
		// Redirects the user back to the login page if the username is not set in the $_SESSION array
		header("Location: login_page.php");
				
		exit();
				
	} 
?>